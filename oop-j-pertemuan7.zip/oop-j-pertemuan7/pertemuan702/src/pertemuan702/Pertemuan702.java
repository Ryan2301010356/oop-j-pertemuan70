/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pertemuan702;

import java.util.Scanner;

/**
 *
 * @author LAB F
 */
public class Pertemuan702 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String ulang ="ya";
        String pil ="";
        Scanner p = new Scanner(System.in);
        
        do{
            System.out.println("Aplikasi AZALAJA");
            System.out.println("1. Hitung Luas Persegi");
            System.out.println("2. Hitung Luas Segitiga");
            System.out.println("3. Selesai");
            System.out.println("Pilih (1/2/3): ");
            pil = p.nextLine();
            switch (pil) {
                case "1":
                System.out.println("Memilih  menu hitung luas persegi");
                break;
                case "2":
                System.out.println("Memilih  menu hitung luas Segitiga");
                break;
                case "3":
                System.out.println("tidak");
                break;
                default:
                     throw new AssertionError ();
                
                     
            }
        }while(ulang.equals("ya"));
        
    }
    
}
