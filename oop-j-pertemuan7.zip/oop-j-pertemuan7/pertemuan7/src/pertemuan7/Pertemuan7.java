package pertemuan7;

/**
 *
 * @author Aryan hidayat
 * TGL: 29-04-2025
 */
public class Pertemuan7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Mahasiswa mhs = new  Mahasiswa();
        mhs.datamhs();
        mhs.datamhs("7777777");
        mhs.datamhs("7777777","aryan");
    }
    
}
